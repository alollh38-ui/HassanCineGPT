Hassan CineGPT AI - Render
Upload this whole project to a GitHub repository.
Render: New Web Service -> GitHub repository.
Build Command: npm install
Start Command: npm start
Environment Variable: REPLICATE_API_TOKEN = your NEW Replicate token
Do NOT put the token in the HTML or send it in chat.
The backend calls Replicate's official prunaai/p-video endpoint.
